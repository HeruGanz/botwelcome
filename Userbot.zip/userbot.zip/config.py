API_ID = 123456
API_HASH = "abcdef123456"
SESSION_STRING = "1A...=="  # Ganti dengan session string asli
